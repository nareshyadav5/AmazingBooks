package com.issuebook.IssueBookApi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IssueBookApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(IssueBookApiApplication.class, args);
	}
	
	
}
