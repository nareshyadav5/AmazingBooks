package com.issuebook.IssueBookApi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IssueBookApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
